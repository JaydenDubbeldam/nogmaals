i = 50
b = 51
antwoord = 0

while antwoord < 1000:
    b = b + 1
    antwoord = i + b
    print(antwoord)