i = 20 
while i < 51:
    print(i)
    i = i + 2